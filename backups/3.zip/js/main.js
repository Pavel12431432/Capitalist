// =======================
// Utility Functions (global)
// =======================

let bondCount = 0; // start from 2 since bondChart1 & bondChart2 exist
const totalBondValue = 7000;
const lightGreen = "#A0D995";

function createBondPieChart(canvasId, value, total, fillColor) {
    const ctx = document.getElementById(canvasId).getContext("2d");
    new Chart(ctx, {
        type: "doughnut",
        data: {
            datasets: [
                {
                    data: [value, total - value],
                    backgroundColor: [fillColor, "#ddd"],
                    borderWidth: 1,
                },
            ],
        },
        options: {
            cutout: "55%",
            responsive: false,
            plugins: {
                legend: { display: false },
                tooltip: { enabled: false },
            },
            events: [], // no hover/click effects
        },
    });
}

function handleBondClick(index) {
    alert(`Bond ${index} clicked`);
}

function addBond(value) {
    bondCount++;

    const wrapper = document.createElement("div");
    wrapper.className = "bond-chart-wrapper";

    const canvas = document.createElement("canvas");
    const chartId = `bondChart${bondCount}`;
    canvas.id = chartId;
    canvas.className = "bond-pie";

    const label = document.createElement("div");
    label.className = "bond-label";
    label.textContent = `$${value.toLocaleString(undefined, {
        minimumFractionDigits: 2,
    })}`;
    label.onclick = () => handleBondClick(bondCount);

    wrapper.appendChild(canvas);
    wrapper.appendChild(label);
    document.querySelector(".bond-charts").appendChild(wrapper);

    createBondPieChart(chartId, value, totalBondValue, lightGreen);
}

// =======================
// DOM Content Init
// =======================

document.addEventListener("DOMContentLoaded", () => {
    // Portfolio pie chart
    const ctx = document.getElementById("portfolioChart").getContext("2d");

    new Chart(ctx, {
        type: "pie",
        data: {
            labels: ["Stocks", "Bonds", "Savings", "Index Fund", "Gold"],
            datasets: [
                {
                    data: [40, 20, 10, 25, 5],
                    backgroundColor: [
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-stock")
                            .trim(),
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-bond")
                            .trim(),
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-savings")
                            .trim(),
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-index")
                            .trim(),
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-gold")
                            .trim(),
                    ],
                    borderWidth: 0,
                },
            ],
        },
        options: {
            responsive: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (context) => {
                            const label = context.label || "";
                            const value = context.parsed;
                            return `${label}: ${value}%`;
                        },
                    },
                },
            },
        },
    });

    addBond(3296.3);
    addBond(3537.2);

    // Fill progress
    function updateYearProgress(percent) {
        const fill = document.querySelector(".vintage-fill");
        fill.style.width = `${percent}%`;
    }

    updateYearProgress(67);

    // === SHARED SETUP ===
    const savingsCard = document.querySelector(".savings-card");
    const actionsContainer = savingsCard.querySelector(".card-actions");

    const depositBtn = savingsCard.querySelector("button:nth-child(2)");
    const withdrawBtn = savingsCard.querySelector("button:nth-child(1)");

    // === DEPOSIT FUNCTIONALITY ===
    let depositActive = false;
    let depositInput, depositCancelBtn, depositMaxBtn, depositWrapper;

    depositBtn.addEventListener("click", () => {
        if (!depositActive) {
            depositWrapper = document.createElement("div");
            depositWrapper.className = "input-wrapper";

            depositInput = document.createElement("input");
            depositInput.type = "number";
            depositInput.className = "savings-input";
            depositInput.placeholder = "$";

            depositMaxBtn = document.createElement("span");
            depositMaxBtn.textContent = "MAX";
            depositMaxBtn.className = "max-label";
            depositMaxBtn.addEventListener("click", () => {
                console.log("max button pressed");
                depositInput.value = "6054.20"; // optional
            });

            depositCancelBtn = document.createElement("button");
            depositCancelBtn.textContent = "✖";
            depositCancelBtn.className = "shadow-button small";
            depositCancelBtn.style.minWidth = "36px";
            depositCancelBtn.style.height = "36px";
            depositCancelBtn.addEventListener("click", () => {
                depositInput.remove();
                depositMaxBtn.remove();
                depositCancelBtn.remove();
                depositWrapper.remove();
                withdrawBtn.style.display = "inline-block";
                depositBtn.style.transform = "none";
                depositActive = false;
            });

            depositWrapper.appendChild(depositMaxBtn);
            depositWrapper.appendChild(depositInput);
            actionsContainer.insertBefore(depositCancelBtn, depositBtn);
            actionsContainer.insertBefore(depositWrapper, depositBtn);

            withdrawBtn.style.display = "none";
            depositBtn.style.transform = "translateX(20px)";
            depositActive = true;
        } else {
            const value = depositInput.value;
            console.log(`Deposited: $${value}`);

            depositInput.remove();
            depositMaxBtn.remove();
            depositCancelBtn.remove();
            depositWrapper.remove();
            withdrawBtn.style.display = "inline-block";
            depositBtn.style.transform = "none";
            depositActive = false;
        }
    });

    // === WITHDRAW FUNCTIONALITY ===
    let withdrawActive = false;
    let withdrawInput, withdrawCancelBtn, withdrawMaxBtn, withdrawWrapper;

    withdrawBtn.addEventListener("click", () => {
        if (!withdrawActive) {
            withdrawWrapper = document.createElement("div");
            withdrawWrapper.className = "input-wrapper";

            withdrawInput = document.createElement("input");
            withdrawInput.type = "number";
            withdrawInput.className = "savings-input";
            withdrawInput.placeholder = "$";

            withdrawMaxBtn = document.createElement("span");
            withdrawMaxBtn.textContent = "MAX";
            withdrawMaxBtn.className = "max-label";
            withdrawMaxBtn.addEventListener("click", () => {
                console.log("max button pressed");
                withdrawInput.value = "8947.69";
            });

            withdrawCancelBtn = document.createElement("button");
            withdrawCancelBtn.textContent = "✖";
            withdrawCancelBtn.className = "shadow-button small";
            withdrawCancelBtn.style.minWidth = "36px";
            withdrawCancelBtn.style.height = "36px";
            withdrawCancelBtn.addEventListener("click", () => {
                withdrawInput.remove();
                withdrawMaxBtn.remove();
                withdrawCancelBtn.remove();
                withdrawWrapper.remove();
                depositBtn.style.display = "inline-block";
                withdrawBtn.style.transform = "none";
                withdrawActive = false;
            });

            withdrawWrapper.appendChild(withdrawMaxBtn);
            withdrawWrapper.appendChild(withdrawInput);
            actionsContainer.insertBefore(withdrawCancelBtn, withdrawBtn);
            actionsContainer.insertBefore(withdrawWrapper, withdrawBtn);

            depositBtn.style.display = "none";
            withdrawBtn.style.transform = "translateX(20px)";
            withdrawActive = true;
        } else {
            const value = withdrawInput.value;
            console.log(`Withdrew: $${value}`);

            withdrawInput.remove();
            withdrawMaxBtn.remove();
            withdrawCancelBtn.remove();
            withdrawWrapper.remove();
            depositBtn.style.display = "inline-block";
            withdrawBtn.style.transform = "none";
            withdrawActive = false;
        }
    });
});
