// =======================
// Utility Functions (global)
// =======================

let bondCount = 0; // start from 2 since bondChart1 & bondChart2 exist
const totalBondValue = 7000;
const lightGreen = "#A0D995";

function createBondPieChart(canvasId, value, total, fillColor) {
    const ctx = document.getElementById(canvasId).getContext("2d");
    new Chart(ctx, {
        type: "doughnut",
        data: {
            datasets: [
                {
                    data: [value, total - value],
                    backgroundColor: [fillColor, "#ddd"],
                    borderWidth: 1,
                },
            ],
        },
        options: {
            cutout: "55%",
            responsive: false,
            plugins: {
                legend: { display: false },
                tooltip: { enabled: false },
            },
            events: [], // no hover/click effects
        },
    });
}

function handleBondClick(index) {
    alert(`Bond ${index} clicked`);
}

function addBond(value) {
    bondCount++;

    const wrapper = document.createElement("div");
    wrapper.className = "bond-chart-wrapper";

    const canvas = document.createElement("canvas");
    const chartId = `bondChart${bondCount}`;
    canvas.id = chartId;
    canvas.className = "bond-pie";

    const label = document.createElement("div");
    label.className = "bond-label";
    label.textContent = `$${value.toLocaleString(undefined, {
        minimumFractionDigits: 2,
    })}`;
    label.onclick = () => handleBondClick(bondCount);

    wrapper.appendChild(canvas);
    wrapper.appendChild(label);
    document.querySelector(".bond-charts").appendChild(wrapper);

    createBondPieChart(chartId, value, totalBondValue, lightGreen);
}

function createInputFlow({
    type,
    button, // depositBtn or withdrawBtn
    siblingButton, // the other one
    container,
    defaultValue,
    onSubmit,
}) {
    let inputActive = false;
    let inputEl, cancelBtn, maxBtn, wrapper;

    button.addEventListener("click", () => {
        if (!inputActive) {
            wrapper = document.createElement("div");
            wrapper.className = "input-wrapper";

            inputEl = document.createElement("input");
            inputEl.type = "number";
            inputEl.className = "savings-input";
            inputEl.placeholder = "$";

            maxBtn = document.createElement("span");
            maxBtn.textContent = "MAX";
            maxBtn.className = "max-label";
            maxBtn.addEventListener("click", () => {
                console.log(`max amount ${type}ed to savings`);
                inputEl.value = defaultValue;
            });

            cancelBtn = document.createElement("button");
            cancelBtn.textContent = "✖";
            cancelBtn.className = "shadow-button small";
            cancelBtn.style.minWidth = "36px";
            cancelBtn.style.height = "36px";
            cancelBtn.addEventListener("click", closeFlow);

            // Keyboard support
            inputEl.addEventListener("keydown", (e) => {
                if (e.key === "Enter") {
                    submitFlow();
                } else if (e.key === "Escape") {
                    closeFlow();
                }
            });

            wrapper.appendChild(maxBtn);
            wrapper.appendChild(inputEl);
            container.insertBefore(cancelBtn, button);
            container.insertBefore(wrapper, button);

            siblingButton.style.display = "none";
            // button.style.transform = "translateX(20px)";
            inputActive = true;
            setTimeout(() => inputEl.focus(), 0); // Autofocus
        } else {
            submitFlow();
        }
    });

    function submitFlow() {
        const value = inputEl.value;
        console.log(
            `${type.charAt(0).toUpperCase() + type.slice(1)}ed: $${value}`
        );
        onSubmit(value);
        closeFlow();
    }

    function closeFlow() {
        inputEl.remove();
        maxBtn.remove();
        cancelBtn.remove();
        wrapper.remove();
        siblingButton.style.display = "inline-block";
        button.style.transform = "none";
        inputActive = false;
    }
}

// =======================
// DOM Content Init
// =======================

document.addEventListener("DOMContentLoaded", () => {
    // Portfolio pie chart
    const ctx = document.getElementById("portfolioChart").getContext("2d");

    new Chart(ctx, {
        type: "pie",
        data: {
            labels: ["Stocks", "Bonds", "Savings", "Index Fund", "Gold"],
            datasets: [
                {
                    data: [40, 20, 10, 25, 5],
                    backgroundColor: [
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-stock")
                            .trim(),
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-bond")
                            .trim(),
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-savings")
                            .trim(),
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-index")
                            .trim(),
                        getComputedStyle(document.documentElement)
                            .getPropertyValue("--chart-gold")
                            .trim(),
                    ],
                    borderWidth: 0,
                },
            ],
        },
        options: {
            responsive: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (context) => {
                            const label = context.label || "";
                            const value = context.parsed;
                            return `${label}: ${value}%`;
                        },
                    },
                },
            },
        },
    });

    addBond(3296.3);
    addBond(3537.2);

    // Fill progress
    function updateYearProgress(percent) {
        const fill = document.querySelector(".vintage-fill");
        fill.style.width = `${percent}%`;
    }

    updateYearProgress(67);

    const savingsCard = document.querySelector(".savings-card");
    const actionsContainer = savingsCard.querySelector(".card-actions");

    const depositBtn = savingsCard.querySelector("button:nth-child(2)");
    const withdrawBtn = savingsCard.querySelector("button:nth-child(1)");

    createInputFlow({
        type: "deposit",
        button: depositBtn,
        siblingButton: withdrawBtn,
        container: actionsContainer,
        defaultValue: "6054.20", // optional
        onSubmit: (val) => {
            // Handle deposit logic here
            console.log(`Deposited $${val} to savings.`);
        },
    });

    createInputFlow({
        type: "withdraw",
        button: withdrawBtn,
        siblingButton: depositBtn,
        container: actionsContainer,
        defaultValue: "8947.69",
        onSubmit: (val) => {
            // Handle withdraw logic here
            console.log(`Withdrew $${val} from savings.`);
        },
    });

    // === INDEX FUND SETUP ===
    const indexCard = document.querySelector(".index-fund-card");
    const indexActions = indexCard.querySelector(".card-actions");

    const indexSellBtn = indexActions.querySelector("button:nth-child(1)");
    const indexBuyBtn = indexActions.querySelector("button:nth-child(2)");

    createInputFlow({
        type: "sell",
        button: indexSellBtn,
        siblingButton: indexBuyBtn,
        container: indexActions,
        defaultValue: "3000.00", // change to your actual available value
        onSubmit: (val) => {
            console.log(`Sold $${val} from Index Fund.`);
        },
    });

    createInputFlow({
        type: "buy",
        button: indexBuyBtn,
        siblingButton: indexSellBtn,
        container: indexActions,
        defaultValue: "6054.20", // or available cash
        onSubmit: (val) => {
            console.log(`Bought Index Fund shares for $${val}.`);
        },
    });

    const goldCard = document.querySelectorAll(".wide-card")[1];
    const goldActions = goldCard.querySelector(".stock-actions");
    const goldSellBtn = goldActions.querySelector("button:nth-child(1)");
    const goldBuyBtn = goldActions.querySelector("button:nth-child(2)");

    createInputFlow({
        type: "sell",
        button: goldSellBtn,
        siblingButton: goldBuyBtn,
        container: goldActions,
        defaultValue: "7498.91", // example: current gold balance
        onSubmit: (val) => {
            console.log(`Sold gold for $${val}.`);
        },
    });

    createInputFlow({
        type: "buy",
        button: goldBuyBtn,
        siblingButton: goldSellBtn,
        container: goldActions,
        defaultValue: "6054.20", // example: available cash
        onSubmit: (val) => {
            console.log(`Bought gold for $${val}.`);
        },
    });

    // === OIL CARD ===
    const oilCard = document.querySelectorAll(".wide-card")[0]; // first wide card
    const oilQuantities = oilCard.querySelectorAll(".stock-quantities button");
    const oilBuyBtn = oilCard.querySelector(
        ".stock-actions button:nth-child(2)"
    );
    const oilSellBtn = oilCard.querySelector(
        ".stock-actions button:nth-child(1)"
    );

    let selectedOilQuantity = 1; // default

    // === Handle quantity selection ===
    oilQuantities.forEach((btn) => {
        btn.addEventListener("click", () => {
            oilQuantities.forEach((b) => b.classList.remove("selected")); // remove from all
            btn.classList.add("selected"); // apply to clicked one

            selectedOilQuantity =
                btn.textContent === "MAX" ? "MAX" : parseInt(btn.textContent);
        });
    });

    // === Initially bold the "1" button ===
    oilQuantities.forEach((btn) => {
        if (btn.textContent === "1") btn.classList.add("selected");
    });

    // === Buy and Sell Handlers ===
    oilBuyBtn.addEventListener("click", () => {
        console.log(`Bought ${selectedOilQuantity} oil shares`);
    });

    oilSellBtn.addEventListener("click", () => {
        console.log(`Sold ${selectedOilQuantity} oil shares`);
    });

    // === APPLY LOGIC TO EACH STOCK CARD ===
    document.querySelectorAll(".stock-card").forEach((card) => {
        const quantityButtons = card.querySelectorAll(
            ".stock-quantities button"
        );
        const sellBtn = card.querySelector(
            ".stock-actions button:nth-child(1)"
        );
        const buyBtn = card.querySelector(".stock-actions button:nth-child(2)");

        let selectedQty = 1;

        // Handle quantity selection
        quantityButtons.forEach((btn) => {
            btn.addEventListener("click", () => {
                quantityButtons.forEach((b) => b.classList.remove("selected"));
                btn.classList.add("selected");

                selectedQty =
                    btn.textContent === "MAX"
                        ? "MAX"
                        : parseInt(btn.textContent);
            });
        });

        // Set default selection to "1"
        quantityButtons.forEach((btn) => {
            if (btn.textContent === "1") btn.classList.add("selected");
        });

        // Handle buy/sell buttons
        buyBtn.addEventListener("click", () => {
            const stockName =
                card.querySelector(".stock-header")?.textContent ||
                "Unknown Stock";
            console.log(`Bought ${selectedQty} shares of ${stockName}`);
        });

        sellBtn.addEventListener("click", () => {
            const stockName =
                card.querySelector(".stock-header")?.textContent ||
                "Unknown Stock";
            console.log(`Sold ${selectedQty} shares of ${stockName}`);
        });
    });

    const bondsCard = document.querySelector(".bonds-card");
    const bondActions = bondsCard.querySelector(".card-actions");
    const bondBuyBtn = bondActions.querySelector(".shadow-button");
    const bondCharts = bondsCard.querySelector(".bond-charts");

    let bondInput = null;
    let bondCancelBtn = null;
    let bondInputWrapper = null;
    let bondOptions = null;
    let bondAPYText = null;
    let bondActive = false;
    let selectedBondYears = 1;

    const apyMap = {
        1: 2.5,
        3: 4.5,
        5: 6.5,
    };

    function createBondBuyOptions() {
        if (bondOptions) return; // Prevent duplicates

        bondOptions = document.createElement("div");
        bondOptions.className = "bond-options";

        [1, 3, 5].forEach((years) => {
            const btn = document.createElement("div");
            btn.className = "bond-circle";
            btn.textContent = `${years}yr`;
            if (years === 1) btn.classList.add("selected");

            btn.addEventListener("click", () => {
                selectedBondYears = years;
                updateBondAPY();
                document
                    .querySelectorAll(".bond-circle")
                    .forEach((c) => c.classList.remove("selected"));
                btn.classList.add("selected");
            });

            bondOptions.appendChild(btn);
        });

        bondsCard.insertBefore(bondOptions, bondActions);
    }

    function updateBondAPY() {
        if (!bondAPYText) {
            bondAPYText = document.createElement("div");
            bondAPYText.className = "bond-apy";
            bondsCard.insertBefore(bondAPYText, bondActions);
        }
        bondAPYText.textContent = `APY: ${apyMap[selectedBondYears]}%`;
    }

    function resetBondFlow() {
        bondInput?.remove();
        bondCancelBtn?.remove();
        bondInputWrapper?.remove();
        bondOptions?.remove();
        bondOptions = null; // allow future re-creation
        bondAPYText?.remove();
        bondAPYText = null;
        bondBuyBtn.style.transform = "none";
        bondCharts.style.display = "flex";
        bondActive = false;
        bondActions.appendChild(bondBuyBtn);
        bondActions.style.display = "flex"; // restore default actions
    }

    bondBuyBtn.addEventListener("click", () => {
        if (!bondActive) {
            bondCharts.style.display = "none";
            createBondBuyOptions();
            updateBondAPY();

            bondInputWrapper = document.createElement("div");
            bondInputWrapper.className = "bond-input-row"; // flex container

            bondCancelBtn = document.createElement("button");
            bondCancelBtn.textContent = "✖";
            bondCancelBtn.className = "shadow-button small";
            bondCancelBtn.style.minWidth = "36px";
            bondCancelBtn.style.height = "36px";
            bondCancelBtn.addEventListener("click", resetBondFlow);

            bondInput = document.createElement("input");
            bondInput.type = "number";
            bondInput.className = "savings-input";
            bondInput.placeholder = "$";

            // Move the BUY button into the row too
            bondBuyBtn.style.transform = "none";
            bondBuyBtn.style.marginTop = "0"; // optional, clean layout

            bondInputWrapper.appendChild(bondCancelBtn);
            bondInputWrapper.appendChild(bondInput);
            bondInputWrapper.appendChild(bondBuyBtn);

            bondsCard.insertBefore(bondInputWrapper, bondActions); // insert above old button location
            bondActions.style.display = "none"; // hide original container

            // Insert the whole input row
            bondsCard.insertBefore(bondInputWrapper, bondActions);

            bondInput.addEventListener("keydown", (e) => {
                if (e.key === "Enter") {
                    confirmBondPurchase();
                } else if (e.key === "Escape") {
                    resetBondFlow();
                }
            });

            bondActive = true;
            setTimeout(() => bondInput.focus(), 0);
        } else {
            confirmBondPurchase();
        }
    });

    function confirmBondPurchase() {
        const value = parseFloat(bondInput.value || "0");
        if (isNaN(value) || value <= 0) return;

        console.log(
            `Bought bond for ${selectedBondYears} years and $${value.toFixed(
                2
            )}`
        );
        resetBondFlow();
        addBond(value); // uses your existing chart logic
    }
});
