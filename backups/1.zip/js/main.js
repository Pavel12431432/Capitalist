document.addEventListener("DOMContentLoaded", () => {
  const ctx = document.getElementById("portfolioChart").getContext("2d");

  new Chart(ctx, {
    type: "pie",
    data: {
      labels: ["Stocks", "Bonds", "Savings", "Index Fund", "Gold"],
      datasets: [
        {
          data: [40, 20, 10, 25, 5], // Example data
          backgroundColor: [
            "#FF6384",
            "#36A2EB",
            "#FFCE56",
            "#A0D995",
            "#E2B0FF",
          ],
          borderColor: "#fff",
          borderWidth: 2,
        },
      ],
    },
    options: {
      responsive: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (context) => {
              const label = context.label || "";
              const value = context.parsed;
              return `${label}: ${value}%`;
            },
          },
        },
      },
    },
  });

  function updateYearProgress(percent) {
    const fill = document.querySelector(".vintage-fill");
    fill.style.width = `${percent}%`;
  }
  
  // Example: Set to 67%
  updateYearProgress(67);

});


