import { getHistoricalPrice } from "./data_manager.js";

export class GameAPI {
    constructor() {
        this.currentQuarter = 0;
        this.previousPrices = {};
        this.totalBondProfit = 0;

        this.cash = 10000;
        this.savings = 1;
        this.bonds = []; // Each bond: { amount: number, years: number }
        this.indexFund = { shares: 0.01, price: 100 };
        this.gold = { ounces: 3, price: 0, totalCost: 0, lifetimeProfit: 0 };
        this.oil = { barrels: 0, price: 4.0, totalCost: 0, lifetimeProfit: 0 };
        this.stocks = {
            "FIZZY DRINKS CO.": { shares: 0, price: 34.0, totalCost: 0 },
            "BIG BANK": { shares: 0, price: 732.2, totalCost: 0 },
            "HEALTHCORE LABS": { shares: 0, price: 67.1, totalCost: 0 },
            "NEWWAVE TECH": { shares: 0, price: 3.49, totalCost: 0 },
        };

        this.stockLifetimeProfit = {};
        for (const name in this.stocks) {
            this.stockLifetimeProfit[name] = 0;
        }
    }

    roundMoney(value) {
        return Number(value.toFixed(2));
    }

    setCash(value) {
        this.cash = this.roundMoney(value);
    }

    depositToSavings(amount) {
        amount = parseFloat(amount.toFixed(2));
        if (amount > this.roundMoney(this.cash)) {
            throw new Error("Not enough cash.");
        }

        this.setCash(this.cash - amount);
        this.savings += amount;
    }

    withdrawFromSavings(amount) {
        amount = parseFloat(amount.toFixed(2));
        if (amount > parseFloat(this.savings.toFixed(2))) {
            throw new Error("Not enough cash.");
        }
        this.setCash(this.cash + amount);
        this.savings -= amount;
        this.savings = this.roundMoney(this.savings);
    }

    buyStock(name, quantity) {
        const stock = this.stocks[name];
        if (!stock) throw new Error("Invalid stock.");

        const roundedCash = parseFloat(this.cash.toFixed(2));
        const sharesToBuy =
            quantity === "MAX"
                ? Math.floor(roundedCash / stock.price)
                : quantity;

        const totalCost = sharesToBuy * stock.price;

        if (
            parseFloat(totalCost.toFixed(2)) > parseFloat(this.cash.toFixed(2))
        ) {
            throw new Error("Not enough cash.");
        }

        stock.shares += sharesToBuy;
        stock.totalCost += totalCost;
        this.setCash(this.cash - totalCost);
    }

    sellStock(name, quantity) {
        const stock = this.stocks[name];
        if (!stock) throw new Error("Invalid stock.");
        const sharesToSell = quantity === "MAX" ? stock.shares : quantity;

        if (sharesToSell <= 0) {
            throw new Error("Insufficient shares.");
        }

        if (sharesToSell > stock.shares)
            throw new Error("Insufficient shares.");

        const avgCost = stock.totalCost / stock.shares;
        const revenue = sharesToSell * stock.price;
        const costBasis = sharesToSell * avgCost;
        const realizedProfit = revenue - costBasis;

        stock.shares -= sharesToSell;
        stock.totalCost -= costBasis;
        this.setCash(this.cash + revenue);

        this.stockLifetimeProfit[name] += realizedProfit;
    }

    buyGold(amount) {
        amount = this.roundMoney(amount);

        if (amount > parseFloat(this.cash.toFixed(2))) {
            throw new Error("Not enough cash.");
        }

        const roundedAmount = parseFloat(amount.toFixed(2));
        const ounces = roundedAmount / this.gold.price;
        const totalCost = ounces * this.gold.price;

        this.setCash(this.cash - amount);
        this.gold.ounces += ounces;
        this.gold.totalCost += totalCost;
    }

    sellGold(amount) {
        amount = this.roundMoney(amount);
        const totalValue = this.gold.ounces * this.gold.price;
        if (amount > parseFloat(totalValue.toFixed(2))) {
            throw new Error("Not enough gold.");
        }

        const ounces = amount / this.gold.price;

        const avgCost = this.gold.totalCost / this.gold.ounces;
        const revenue = ounces * this.gold.price;
        const costBasis = ounces * avgCost;
        const realizedProfit = revenue - costBasis;

        this.gold.ounces -= ounces;
        this.gold.totalCost -= costBasis;
        this.setCash(this.cash + amount);

        this.gold.lifetimeProfit += realizedProfit;

        // Snap near-zero values to zero
        if (Math.abs(this.gold.ounces) < 1e-4) {
            this.gold.ounces = 0;
        }
    }

    getGoldValue() {
        return this.gold.ounces * this.gold.price;
    }

    getGoldProfit() {
        const currentValue = this.getGoldValue();
        const unrealized =
            this.gold.ounces > 0 ? currentValue - this.gold.totalCost : 0;
        return this.gold.lifetimeProfit + unrealized;
    }

    getLifetimeStockProfit(name) {
        const stock = this.stocks[name];
        const unrealized =
            stock.shares > 0 ? stock.shares * stock.price - stock.totalCost : 0;

        return this.stockLifetimeProfit[name] + unrealized;
    }

    buyIndexFund(amount) {
        amount = parseFloat(amount);

        if (parseFloat(amount.toFixed(2)) > parseFloat(this.cash.toFixed(2))) {
            throw new Error("Not enough cash.");
        }

        const roundedAmount = parseFloat(amount.toFixed(2));
        const sharesToBuy = roundedAmount / this.indexFund.price;
        this.setCash(this.cash - amount);
        this.indexFund.shares += sharesToBuy;
    }

    sellIndexFund(amount) {
        amount = parseFloat(amount);
        const totalValue = this.indexFund.shares * this.indexFund.price;
        if (parseFloat(amount.toFixed(2)) > parseFloat(totalValue.toFixed(2))) {
            throw new Error("Not enough index fund value.");
        }

        const sharesToSell = amount / this.indexFund.price;
        this.indexFund.shares -= sharesToSell;
        this.setCash(this.cash + amount);

        // Snap near-zero values to zero
        if (Math.abs(this.indexFund.shares) < 1e-4) {
            this.indexFund.shares = 0;
        }
    }

    buyBond(amount, years) {
        const APY_MAP = { 1: 0.025, 3: 0.045, 5: 0.065 };

        if (parseFloat(amount.toFixed(2)) > parseFloat(this.cash.toFixed(2))) {
            throw new Error("Not enough cash.");
        }

        if (![1, 3, 5].includes(years)) throw new Error("Invalid bond term.");

        const QUARTERS_MAP = { 1: 4, 3: 12, 5: 20 };

        this.setCash(this.cash - amount);
        this.bonds.push({
            principal: amount,
            apy: APY_MAP[years],
            term: QUARTERS_MAP[years],
            startQuarter: this.currentQuarter,
            redeemed: false,
        });
    }

    getBondProgress(bond) {
        const elapsed = this.currentQuarter - bond.startQuarter;
        return Math.min(elapsed / bond.term, 1);
    }

    calculateBondValue(bond, currentQuarter = this.currentQuarter) {
        if (bond.redeemed) return 0;

        const quartersPassed = Math.min(
            currentQuarter - bond.startQuarter,
            bond.term
        );
        const yearsPassed = Math.floor(quartersPassed / 4);

        return bond.principal * Math.pow(1 + bond.apy, yearsPassed);
    }

    getBondValue() {
        return this.bonds.reduce((sum, bond) => {
            return sum + this.calculateBondValue(bond);
        }, 0);
    }

    redeemBond(index) {
        const bond = this.bonds[index];
        if (!bond || bond.redeemed) throw new Error("Invalid bond.");

        const payout = this.calculateBondValue(bond);
        const profit = payout - bond.principal;
        this.totalBondProfit += profit;

        this.setCash(this.cash + payout);
        bond.redeemed = true;
    }

    buyOil(barrels) {
        const cost = this.oil.price * barrels;
        if (parseFloat(cost.toFixed(2)) > parseFloat(this.cash.toFixed(2))) {
            throw new Error("Not enough cash.");
        }
        this.setCash(this.cash - cost);
        this.oil.barrels += barrels;

        const totalCost = barrels * this.oil.price;
        this.oil.totalCost += totalCost;
    }

    sellOil(barrels) {
        if (barrels > this.oil.barrels)
            throw new Error("Not enough oil barrels.");

        const avgCost = this.oil.totalCost / this.oil.barrels;
        const revenue = barrels * this.oil.price;
        const costBasis = barrels * avgCost;
        const realizedProfit = revenue - costBasis;

        const value = this.oil.price * barrels;
        this.oil.barrels -= barrels;
        this.oil.totalCost -= costBasis;
        this.setCash(this.cash + value);
        this.oil.lifetimeProfit += realizedProfit;
    }

    getOilProfit() {
        const currentValue = this.oil.barrels * this.oil.price;
        const unrealized =
            this.oil.barrels > 0 ? currentValue - this.oil.totalCost : 0;
        return this.oil.lifetimeProfit + unrealized;
    }

    getNetWorth() {
        const stockValue = Object.values(this.stocks).reduce(
            (sum, s) => sum + s.shares * s.price,
            0
        );
        return (
            this.cash +
            this.savings +
            this.getBondValue() +
            this.getGoldValue() +
            this.indexFund.shares * this.indexFund.price +
            this.oil.barrels * this.oil.price +
            stockValue
        );
    }

    getGameState() {
        return {
            cash: this.cash,
            savings: this.savings,
            oil: this.oil,
            gold: {
                price: this.gold.price,
                balance: this.getGoldValue(),
            },
            bonds: this.bonds,
            indexFund: this.indexFund,
            stocks: this.stocks,
            netWorth: this.getNetWorth(),
            currentYear: this.getCurrentYear(),
            currentQuarter: this.currentQuarter,
        };
    }

    updatePrices() {
        for (const name in this.stocks) {
            this.previousPrices[name] = this.stocks[name].price;

            const price = getHistoricalPrice(
                "stocks",
                name,
                this.currentQuarter
            );
            if (price != null) this.stocks[name].price = price;
        }

        this.previousPrices.gold = this.gold.price;
        const goldPrice = getHistoricalPrice(
            "commodities",
            "gold",
            this.currentQuarter
        );
        if (goldPrice != null) this.gold.price = goldPrice;

        this.previousPrices.oil = this.oil.price;
        const oilPrice = getHistoricalPrice(
            "commodities",
            "oil",
            this.currentQuarter
        );
        if (oilPrice != null) this.oil.price = oilPrice;

        this.previousPrices.indexFund = this.indexFund.value;
        const indexFundPrice = getHistoricalPrice(
            "indexFund",
            null,
            this.currentQuarter
        );
        if (indexFundPrice != null) this.indexFund.price = indexFundPrice;
    }

    advanceQuarter() {
        if (this.currentQuarter > 79)
            return
        this.currentQuarter += 1;
        if (this.currentQuarter % 4 == 0) {
            this.setCash(this.cash + 10000);
            this.savings = this.roundMoney(1.01 * this.savings);
        }
        this.updatePrices();
    }

    getCurrentYear() {
        return Math.floor(this.currentQuarter / 4);
    }
}
