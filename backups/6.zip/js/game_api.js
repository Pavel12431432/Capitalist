export class GameAPI {
    constructor() {
        this.currentYear = 0;

        this.cash = 10000;
        this.savings = 1;
        this.bonds = []; // Each bond: { amount: number, years: number }
        this.indexFund = { value: 2 };
        this.gold = { balance: 3 };
        this.oil = { barrels: 1178, price: 4.0 };
        this.stocks = {
            "IT’S ELECTRIC! INC.": { shares: 163, price: 34.0 },
            "BIG BANK": { shares: 31, price: 732.2 },
            "STRONG OIL CO.": { shares: 92, price: 67.1 },
            "JADE'S PAINT CO.": { shares: 2134, price: 3.49 },
        };
    }

    depositToSavings(amount) {
        amount = parseFloat(amount);
        if (amount > this.cash) throw new Error("Not enough cash.");
        this.cash -= amount;
        this.savings += amount;
    }

    withdrawFromSavings(amount) {
        amount = parseFloat(amount);
        if (amount > this.savings) throw new Error("Not enough savings.");
        this.cash += amount;
        this.savings -= amount;
    }

    buyStock(name, quantity) {
        const stock = this.stocks[name];
        if (!stock) throw new Error("Invalid stock.");
        const totalCost =
            quantity === "MAX" ? this.cash : stock.price * quantity;
        const sharesToBuy =
            quantity === "MAX" ? Math.floor(this.cash / stock.price) : quantity;
        if (stock.price * sharesToBuy > this.cash)
            throw new Error("Insufficient cash.");
        stock.shares += sharesToBuy;
        this.cash -= stock.price * sharesToBuy;
    }

    sellStock(name, quantity) {
        const stock = this.stocks[name];
        if (!stock) throw new Error("Invalid stock.");
        const sharesToSell = quantity === "MAX" ? stock.shares : quantity;
        if (sharesToSell > stock.shares)
            throw new Error("Insufficient shares.");
        stock.shares -= sharesToSell;
        this.cash += stock.price * sharesToSell;
    }

    buyGold(amount) {
        amount = parseFloat(amount);
        if (amount > this.cash) throw new Error("Not enough cash.");
        this.cash -= amount;
        this.gold.balance += amount;
    }

    sellGold(amount) {
        amount = parseFloat(amount);
        if (amount > this.gold.balance) throw new Error("Not enough gold.");
        this.gold.balance -= amount;
        this.cash += amount;
    }

    buyIndexFund(amount) {
        amount = parseFloat(amount);
        if (amount > this.cash) throw new Error("Not enough cash.");
        this.cash -= amount;
        this.indexFund.value += amount;
    }

    sellIndexFund(amount) {
        amount = parseFloat(amount);
        if (amount > this.indexFund.value)
            throw new Error("Not enough index fund value.");
        this.indexFund.value -= amount;
        this.cash += amount;
    }

    buyBond(amount, years) {
        const APY_MAP = { 1: 0.025, 3: 0.045, 5: 0.065 };

        if (amount > this.cash) throw new Error("Not enough cash.");
        if (![1, 3, 5].includes(years)) throw new Error("Invalid bond term.");

        this.cash -= amount;
        this.bonds.push({
            principal: amount,
            years,
            apy: APY_MAP[years],
            startYear: this.currentYear,
            redeemed: false,
        });
    }

    getBondProgress(bond) {
        const elapsed = this.currentYear - bond.startYear;
        return Math.min(elapsed / bond.years, 1);
    }

    redeemBond(index) {
        const bond = this.bonds[index];
        if (!bond || bond.redeemed) throw new Error("Invalid bond.");

        const elapsed = this.currentYear - bond.startYear;
        if (elapsed < bond.years) throw new Error("Bond not matured yet.");

        const payout = bond.principal * Math.pow(1 + bond.apy, bond.years);
        this.cash += payout;
        bond.redeemed = true;
    }

    buyOil(barrels) {
        const cost = this.oil.price * barrels;
        if (cost > this.cash) throw new Error("Not enough cash.");
        this.cash -= cost;
        this.oil.barrels += barrels;
    }

    sellOil(barrels) {
        if (barrels > this.oil.barrels)
            throw new Error("Not enough oil barrels.");
        const value = this.oil.price * barrels;
        this.oil.barrels -= barrels;
        this.cash += value;
    }

    getNetWorth() {
        const bondTotal = this.bonds.reduce((sum, b) => sum + b.amount, 0);
        const stockValue = Object.values(this.stocks).reduce(
            (sum, s) => sum + s.shares * s.price,
            0
        );
        return (
            this.cash +
            this.savings +
            bondTotal +
            this.gold.balance +
            this.indexFund.value +
            stockValue
        );
    }

    getGameState() {
        return {
            cash: this.cash,
            savings: this.savings,
            oil: this.oil,
            gold: this.gold,
            bonds: this.bonds,
            indexFund: this.indexFund,
            stocks: this.stocks,
            netWorth: this.getNetWorth(),
            currentYear: this.currentYear,
        };
    }
}
