// =======================
// Utility Functions (global)
// =======================

let bondCount = 0; // start from 2 since bondChart1 & bondChart2 exist
const totalBondValue = 7000;
const lightGreen = "#A0D995";

function createBondPieChart(canvasId, value, total, fillColor) {
  const ctx = document.getElementById(canvasId).getContext("2d");
  new Chart(ctx, {
    type: "doughnut",
    data: {
      datasets: [
        {
          data: [value, total - value],
          backgroundColor: [fillColor, "#ddd"],
          borderWidth: 1,
        },
      ],
    },
    options: {
      cutout: "55%",
      responsive: false,
      plugins: {
        legend: { display: false },
        tooltip: { enabled: false },
      },
      events: [], // no hover/click effects
    },
  });
}

function handleBondClick(index) {
  alert(`Bond ${index} clicked`);
}

function addBond(value) {
  bondCount++;

  const wrapper = document.createElement("div");
  wrapper.className = "bond-chart-wrapper";

  const canvas = document.createElement("canvas");
  const chartId = `bondChart${bondCount}`;
  canvas.id = chartId;
  canvas.className = "bond-pie";

  const label = document.createElement("div");
  label.className = "bond-label";
  label.textContent = `$${value.toLocaleString(undefined, {
    minimumFractionDigits: 2,
  })}`;
  label.onclick = () => handleBondClick(bondCount);

  wrapper.appendChild(canvas);
  wrapper.appendChild(label);
  document.querySelector(".bond-charts").appendChild(wrapper);

  createBondPieChart(chartId, value, totalBondValue, lightGreen);
}

// =======================
// DOM Content Init
// =======================

document.addEventListener("DOMContentLoaded", () => {
  // Portfolio pie chart
  const ctx = document.getElementById("portfolioChart").getContext("2d");

  new Chart(ctx, {
    type: "pie",
    data: {
      labels: ["Stocks", "Bonds", "Savings", "Index Fund", "Gold"],
      datasets: [
        {
          data: [40, 20, 10, 25, 5],
          backgroundColor: [
            getComputedStyle(document.documentElement)
              .getPropertyValue("--chart-stock")
              .trim(),
            getComputedStyle(document.documentElement)
              .getPropertyValue("--chart-bond")
              .trim(),
            getComputedStyle(document.documentElement)
              .getPropertyValue("--chart-savings")
              .trim(),
            getComputedStyle(document.documentElement)
              .getPropertyValue("--chart-index")
              .trim(),
            getComputedStyle(document.documentElement)
              .getPropertyValue("--chart-gold")
              .trim(),
          ],
          borderColor: "#fff",
          borderWidth: 2,
        },
      ],
    },
    options: {
      responsive: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (context) => {
              const label = context.label || "";
              const value = context.parsed;
              return `${label}: ${value}%`;
            },
          },
        },
      },
    },
  });

  addBond(3296.3);
  addBond(3537.2);

  // Fill progress
  function updateYearProgress(percent) {
    const fill = document.querySelector(".vintage-fill");
    fill.style.width = `${percent}%`;
  }

  updateYearProgress(67);
});
